<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Penlok_targetkkModel extends CI_Model {

	

}

/* End of file penlok_targetkkModel.php */
/* Location: ./application/models/penlok_targetkkModel.php */