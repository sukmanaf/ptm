<div class="col-md-12">
	<div class="row">
		<div class="col-lg-3 col-xs-6">
			<div class="small-box bg-info">
				<div class="inner">
					<h3>&nbsp;</h3>
					<p>Penetapan Lokasi dan target KK</p>
				</div>
				<div class="icon">
					<i class="ion ion-calendar"></i>
				</div>
				<a href="<?=base_url()?>penlok_targetkk" class="small-box-footer">
					<i class="fa fa-arrow-circle-right"></i>
				</a>
			</div>
		</div>

		<div class="col-lg-3 col-xs-6">

			<div class="small-box bg-info">
				<div class="inner">
					<h3>&nbsp;</h3>
					<p>Penyuluhan</p>
				</div>
				<div class="icon">
					<i class="ion ion-calendar"></i>
				</div>
				<a href="<?=base_url()?>penyuluhan" class="small-box-footer">
					<i class="fa fa-arrow-circle-right"></i>
				</a>
			</div>
		</div>

		<div class="col-lg-3 col-xs-6">

			<div class="small-box bg-info">
				<div class="inner">
					<h3>&nbsp;</h3>
					<p>Pemetaan Sosial</p>
				</div>
				<div class="icon">
					<i class="ion ion-calendar"></i>
				</div>
				<a href="<?=base_url()?>pemetaan_sosial" class="small-box-footer">
					<i class="fa fa-arrow-circle-right"></i>
				</a>
			</div>
		</div>

		<div class="col-lg-3 col-xs-6">
			<div class="small-box bg-info">
				<div class="inner">
					<h3>&nbsp;</h3>
					<p>Penetapan Model Pemberdayaan</p>
				</div>
				<div class="icon">
					<i class="ion ion-calendar"></i>
				</div>
				<a href="<?=base_url()?>subjectobject/tahun_pertama/model_pemberdayaan" class="small-box-footer">
					<i class="fa fa-arrow-circle-right"></i>
				</a>
			</div>
		</div>

		<div class="col-lg-3 col-xs-6">
			<div class="small-box bg-info">
				<div class="inner">
					<h3>&nbsp;</h3>
					<p>Penyusunan Data Penerima Akses </p>
				</div>
				<div class="icon">
					<i class="ion ion-calendar"></i>
				</div>
				<a href="<?=base_url()?>subjectobject/tahun_pertama/penyusunandata" class="small-box-footer">
					<i class="fa fa-arrow-circle-right"></i>
				</a>
			</div>
		</div>
	</div>
>
</div>