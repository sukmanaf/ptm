<div class="row" style="padding: 10px">
	<div class="col-lg-3 col-xs-6">
		<div class="small-box bg-info">
			<div class="inner">
				<h3>&nbsp;</h3>
				<p> Pengembangan Rencana Usaha</p>
			</div>
			<div class="icon">
				<i class="ion ion-calendar"></i>
			</div>
			<a href="<?=base_url()?>pengembangan" class="small-box-footer">
				<i class="fa fa-arrow-circle-right"></i>
			</a>
		</div>
	</div>

	<div class="col-lg-3 col-xs-6">
		<div class="small-box bg-info">
			<div class="inner">
				<h3>&nbsp;</h3>
				<p>Fasilitasi Akses Pemasaran</p>
			</div>
			<div class="icon">
				<i class="ion ion-calendar"></i>
			</div>
			<a href="<?=base_url()?>fasilitasi_akses" class="small-box-footer">
				<i class="fa fa-arrow-circle-right"></i>
			</a>
		</div>
	</div>

	<div class="col-lg-3 col-xs-6">
		<div class="small-box bg-info">
			<div class="inner">
				<h3>&nbsp;</h3>
				<p>Fasilitasi Infrastruktur Pendukung</p>
			</div>
			<div class="icon">
				<i class="ion ion-calendar"></i>
			</div>
			<a href="<?=base_url()?>fasilitasi_infrastruktur" class="small-box-footer">
				<i class="fa fa-arrow-circle-right"></i>
			</a>
		</div>
	</div>

	<div class="col-lg-3 col-xs-6">
		<div class="small-box bg-info">
			<div class="inner">
				<h3>&nbsp;</h3>
				<p>Diseminasi Model Akses Reforma Agrari</p>
			</div>
			<div class="icon">
				<i class="ion ion-calendar"></i>
			</div>
			<a href="<?=base_url()?>diseminasi" class="small-box-footer">
				<i class="fa fa-arrow-circle-right"></i>
			</a>
		</div>
	</div>
</div>