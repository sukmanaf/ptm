<div class="row" style="margin: 10px">
	<div class="col-lg-3 col-xs-6">

		<div class="small-box bg-info">
			<div class="inner">
				<h3>&nbsp;</h3>
				<p>Penguatan Kelembagaan</p>
			</div>
			<div class="icon">
				<i class="ion ion-calendar"></i>
			</div>
			<a href="/ptm-web/subject_object/tahun_kedua/penguatan_kelembagaan" class="small-box-footer">
				<i class="fa fa-arrow-circle-right"></i>
			</a>
		</div>
	</div>

	<div class="col-lg-3 col-xs-6">
		<div class="small-box bg-info">
			<div class="inner">
				<h3>&nbsp;</h3>
				<p>Pendampingan Kewirausahaan</p>
			</div>
			<div class="icon">
				<i class="ion ion-calendar"></i>
			</div>
			<a href="#" class="small-box-footer">
				<i class="fa fa-arrow-circle-right"></i>
			</a>
		</div>
	</div>

	<div class="col-lg-3 col-xs-6">
		<div class="small-box bg-info">
			<div class="inner">
				<h3>&nbsp;</h3>
				<p>Pembentukan Kerjasama</p>
			</div>
			<div class="icon">
				<i class="ion ion-calendar"></i>
			</div>
			<a href="#" class="small-box-footer">
				<i class="fa fa-arrow-circle-right"></i>
			</a>
		</div>
	</div>

	<div class="col-lg-3 col-xs-6">
		<div class="small-box bg-info">
			<div class="inner">
				<h3>&nbsp;</h3>
				<p>Penyusunan SK Pembentukan Kelompok Masyarakat</p>
			</div>
			<div class="icon">
				<i class="ion ion-calendar"></i>
			</div>
			<a href="#" class="small-box-footer">
				<i class="fa fa-arrow-circle-right"></i>
			</a>
		</div>
	</div>
</div>